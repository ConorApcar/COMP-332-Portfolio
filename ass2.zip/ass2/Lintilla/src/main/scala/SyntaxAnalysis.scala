/*
 * This file is part of COMP332 Assignment 2 2018.
 *
 * Lintilla, a simple functional programming language.
 *
 * © 2018, Dominic Verity and Anthony Sloane, Macquarie University.
 *         All rights reserved.
 *
 * This Source Code Form is subject to the terms of the Mozilla Public
 * License, v. 2.0. If a copy of the MPL was not distributed with this
 * file, You can obtain one at http://mozilla.org/MPL/2.0/.
 *
 * Parser for the Lintilla language.
 */

package lintilla

import org.bitbucket.inkytonik.kiama.parsing.Parsers
import org.bitbucket.inkytonik.kiama.util.Positions

/**
 * Module containing parsers for Lintilla.
 */
class SyntaxAnalysis (positions : Positions)
    extends Parsers (positions) {

  import LintillaTree._
  import scala.language.postfixOps

  // Top level parser.
  lazy val parser : PackratParser[Program] =
    phrase(program)

  // Parses a whole Lintilla program.
  lazy val program : PackratParser[Program] =
    repsep(exp, ";") ^^ Program    // Repeat an expression seperated by a ';' until the end of the program

  // Parses an expression
  lazy val exp : PackratParser[Expression] =
    assign | pexp | ifexp | whileexp |
    returnexp | letdecl | fndecl    // List of all parsers that exp will use to create an expression

  // Parses expressions with symbols =, <
  lazy val pexp : PackratParser[Expression] =
    pexp ~ ("=" ~> pexp1) ^^ EqualExp |
    pexp ~ ("<" ~> pexp1) ^^ LessExp |
    pexp1    // Moves onto the next pexp in terms of precedence

  // Parses expressions with symbols +, -
  lazy val pexp1 : PackratParser [Expression] =
    pexp1 ~ ("+" ~> pexp2) ^^ PlusExp |
    pexp1 ~ ("-" ~> pexp2) ^^ MinusExp |
    pexp2    // Moves onto the next pexp in terms of precedence

  // Parses expressions with symbols *, /
  lazy val pexp2 : PackratParser[Expression] =
    pexp2 ~ ("*" ~> pexp3) ^^ StarExp |
    pexp2 ~ ("/" ~> pexp3) ^^ SlashExp |
    pexp3    // Moves onto the next pexp in terms of precedence

  // Parses expressions with remaining precednece expressions.
  lazy val pexp3 : PackratParser[Expression] =
    ("-" ~> pexp3) ^^ NegExp |
    "false" ^^^ BoolExp(false) |
    "true" ^^^ BoolExp(true) |
    integer ^^ (s => IntExp(s.toInt)) |    // Converts integer to an int
    app |    // Goes to app parser
    "(" ~> exp <~ ")" |    // Closes an expression within parentheses
    block    // Goes to block parser

  // Parses an application by applying the left expression to the right
  lazy val app : PackratParser[Expression] =
    app ~ ("(" ~> repsep(exp, ",") <~ ")") ^^ AppExp |
    idnuse ^^ IdnExp    // If name has already been used and does not need to be applied

  // Parses an assignment of an expression
  lazy val assign : PackratParser[AssignExp] =
    (idnuse <~ ":=") ~ exp ^^ AssignExp

  // Parses a block expression
  lazy val block : PackratParser[Block] =
    "{" ~> repsep(exp, ";") <~ "}" ^^ Block

  // Parses an if statement
  lazy val ifexp : PackratParser[IfExp] =
    ("if" ~> exp) ~ block ~ ("else" ~> block) ^^ IfExp

  // Parses a while statement
  lazy val whileexp : PackratParser[WhileExp] =
    ("while" ~> exp) ~ block ^^ WhileExp

  // Parses a return value from the block
  lazy val returnexp : PackratParser[Return] =
    "return" ~> opt(exp) ^^ Return    // Expression is optional, still functions without one

  // Parses a let expression
  lazy val letdecl : PackratParser[Expression] =
    ("let" ~> opt("mut")) ~ (idndef <~ "=") ~ exp ^^ {
      case None ~ i ~ e => LetDecl(i, e)    // Declares an immutable variable
      case Some(_) ~ i ~ e => LetMutDecl(i, e)    // Declares a mutable variable
    }

  // Parses a new named function
  lazy val fndecl : PackratParser[FnDecl] =
    ("fn" ~> idndef) ~ ("(" ~> repsep(paramdecl, ",") <~ ")") ~ (opt("->" ~> tipe)) ~ block ^^ FnDecl
    // Type is optional in the function, does not need to be declared to work

  // Parses a single parameter declaration
  lazy val paramdecl : PackratParser[ParamDecl] =
    (idndef <~ ":") ~ tipe ^^ ParamDecl

  // Parses types
  lazy val tipe : PackratParser[Type] =
    "unit" ^^^ UnitType() |
    "bool" ^^^ BoolType() |
    "int" ^^^ IntType() |
    ("fn" ~> "(" ~> repsep(tipe, ",") <~ ")") ~ (opt("->" ~> tipe)) ^^ {
      case r ~ None => FnType(r, UnitType())    // Does not have a result type
      case r ~ Some(t) => FnType(r, t) } |    // Does have a result type
    "(" ~> tipe <~ ")"    // Encloses a type in parentheses

  // FIXME Add your parsers here!

  // Parses a literal integer.
  lazy val integer : PackratParser[String] =
    regex("[0-9]+".r)

  // Parses a defining occurence of an identifier.
  lazy val idndef : PackratParser[IdnDef] =
    identifier ^^ IdnDef

  // Parses an applied occurence of an identifier.
  lazy val idnuse : PackratParser[IdnUse] =
    identifier ^^ IdnUse

  // Parses a legal identifier. Checks to ensure that the word parsed is
  // not a Lintilla keyword.
  lazy val identifier : PackratParser[String] =
    (not(keyword) | failure("identifier expected but keyword found")) ~>
      "[a-zA-Z][a-zA-Z0-9_]*".r

  // Parses any legal Lintilla keyword. This parser ensures that the keyword found
  // is not a prefix of an longer identifier. So this parser will not parse the
  // "int" prefix of "integer" as a keyword.
  lazy val keyword =
    keywords("[^a-zA-Z0-9_]".r,
             List("bool", "else", "false", "fn", "if", "int", "let", "mut",
                  "return", "true", "unit", "while")) |
      failure("expecting keyword")

  // We use the character class `\R` here to match line endings, so that we correctly
  // handle all of the end-line variants in un*x, MacOSX, MS Windows, and unicode.
  override val whitespace: Parser[String] =
    """(\s|(//.*(\R|\z)))*""".r
}
