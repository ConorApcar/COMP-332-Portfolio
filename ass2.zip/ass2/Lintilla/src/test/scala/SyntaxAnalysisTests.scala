/*
 * This file is part of COMP332 Assignment 2 2018.
 *
 * Lintilla, a simple functional programming language.
 *
 * © 2018, Dominic Verity and Anthony Sloane, Macquarie University.
 *         All rights reserved.
 *
 * This Source Code Form is subject to the terms of the Mozilla Public
 * License, v. 2.0. If a copy of the MPL was not distributed with this
 * file, You can obtain one at http://mozilla.org/MPL/2.0/.
 *
 * Tests of the parser of the Lintilla language.
 */

package lintilla

import org.bitbucket.inkytonik.kiama.util.ParseTests
import org.junit.runner.RunWith
import org.scalatest.junit.JUnitRunner

/**
  * Tests that check that the parser works correctly.  I.e., it accepts correct
  * input and produces the appropriate trees, and it rejects illegal input.
  */
@RunWith(classOf[JUnitRunner])
class SyntaxAnalysisTests extends ParseTests {

  import LintillaTree._

  val parsers = new SyntaxAnalysis(positions)
  import parsers._

  // Tests of parsing terminals

  test("parsing an identifier of one letter produces the correct tree") {
    identifier("x") should parseTo[String]("x")
  }

  test("parsing an identifier as an applied instance produces the correct tree") {
    idnuse("count") should parseTo[IdnUse](IdnUse("count"))
  }

  test("parsing an identifier containing digits and underscores produces the correct tree") {
    idndef("x1_2_3") should parseTo[IdnDef](IdnDef("x1_2_3"))
  }

  test("parsing an integer as an identifier gives an error") {
    identifier("42") should
    failParseAt(1, 1,
                "string matching regex '[a-zA-Z][a-zA-Z0-9_]*' expected but '4' found")
  }

  test("parsing a non-identifier as an identifier gives an error (digit)") {
    identifier("4foo") should
    failParseAt(1, 1,
                "string matching regex '[a-zA-Z][a-zA-Z0-9_]*' expected but '4' found")
  }

  test("parsing a non-identifier as an identifier gives an error (underscore)") {
    identifier("_f3") should
    failParseAt(1, 1,
                "string matching regex '[a-zA-Z][a-zA-Z0-9_]*' expected but '_' found")
  }

  test("parsing a keyword as an identifier gives an error") {
    identifier("let ") should failParseAt(1, 1,
                                          "identifier expected but keyword found")
  }

  test("parsing a keyword prefix as an identifier produces the correct tree") {
    identifier("letter") should parseTo[String]("letter")
  }

  test("parsing an integer of one digit as an integer produces the correct tree") {
    integer("8") should parseTo[String]("8")
  }

  test("parsing an integer as an integer produces the correct tree") {
    integer("99") should parseTo[String]("99")
  }

  test("parsing a non-integer as an integer gives an error") {
    integer("total") should
    failParseAt(1, 1,
                "string matching regex '[0-9]+' expected but 't' found")
  }

  // FIXME Add tests of your parsers.

  // Testing  general expression
  test("Parsing a simple expression") {
    exp("2 + 3 * 4") should
    parseTo[Expression](
      PlusExp(
        IntExp(2),
        StarExp(
          IntExp(3),
          IntExp(4)))
    )
  }


  // Testing of the assign parser
  test("Parsing an expression to assign a values to x") {
    assign("x := 2 * x - 1") should
    parseTo[Expression](
      AssignExp(
        IdnUse("x"),
        MinusExp(
          StarExp(
            IntExp(2),
            IdnExp(IdnUse("x"))),
          IntExp(1)))
    )
  }

  test("Parsing an incorrect assign expression to see if it fails") {
    assign("x = 2 * x - 1") should
    failParseAt(1,3, "':=' expected but '=' found")
  }

  // Testing of the app parser
  test("Parsing a function to apply a value to it") {
    app("double(4)") should
    parseTo[Expression](
      AppExp(IdnExp(IdnUse("double")), Vector(IntExp(4)))
    )
  }

  test("Parsing an empty vector to apply to a function") {
    app("double()") should
    parseTo[Expression](
      AppExp(IdnExp(IdnUse("double")), Vector())
    )
  }

  //Testing the block parser
  test("Parsing an if statement within a block statement") {
    block("{if x = y { if true { 3 } else { 4 } } else { 5 }};") should
    parseTo[Expression](
      Block(
        Vector(
          IfExp(
            EqualExp(IdnExp(IdnUse("x")), IdnExp(IdnUse("y"))),
            Block(
              Vector(
                IfExp(
                  BoolExp(true),
                  Block(Vector(IntExp(3))),
                  Block(Vector(IntExp(4)))))),
            Block(Vector(IntExp(5))))))
    )
  }

  test("Parsing an empty block statement") {
    block("{}") should
    parseTo[Expression](
      Block(Vector())
    )
  }

  test("Parsing a block statement without a closing '}' should fail") {
    block("{if x = y { 5 } else { 4 }") should
    failParseAt(1,27, "'}' expected but end of source found")
  }

  //Testing the ifexp parser
  test("Parsing an if statement through the ifexp parser") {
    ifexp("if x < 0 { 1 } else { 2 };") should
    parseTo[Expression](
      IfExp(
        LessExp(IdnExp(IdnUse("x")), IntExp(0)),
        Block(Vector(IntExp(1))),
        Block(Vector(IntExp(2))))
    )
  }

  test("Parsing an if statement that returns empty blocks") {
    ifexp("if x < 0 {} else {};") should
    parseTo[Expression](
      IfExp(
        LessExp(IdnExp(IdnUse("x")), IntExp(0)),
        Block(Vector()),
        Block(Vector()))
    )
  }

  test("Parsing an if statement that uses a return parser in its blocks") {
    ifexp("if x < 0 {return 5} else {return blue};") should
    parseTo[Expression](
      IfExp(
        LessExp(IdnExp(IdnUse("x")), IntExp(0)),
        Block(Vector(Return(Some(IntExp(5))))),
        Block(Vector(Return(Some(IdnExp(IdnUse("blue")))))))
    )
  }

  test("Parsing an if statement that does not have an else statement") {
    ifexp("if x < 0 { 1 };") should
    failParseAt(1,15, "'else' expected but ';' found")
  }

  //Testing the whileexp parser
  test("Parsing a while statement") {
    whileexp("while (0 < x) { x = 5 }") should
    parseTo[Expression](
      WhileExp(
        LessExp(IntExp(0), IdnExp(IdnUse("x"))),
        Block(
          Vector(
            EqualExp(
              IdnExp(IdnUse("x")),
              IntExp(5)))))
    )
  }

  test("Parsing a while statement that uses if statements in it") {
    whileexp("while (0 < x) {if x < 0 { 1 } else { 2 }};") should
    parseTo[Expression](
      WhileExp(
        LessExp(IntExp(0), IdnExp(IdnUse("x"))),
        Block(
          Vector(
            IfExp(
              LessExp(IdnExp(IdnUse("x")), IntExp(0)),
              Block(Vector(IntExp(1))),
              Block(Vector(IntExp(2)))))))
    )
  }

  test("Parsing a while statement with an empty block") {
    whileexp("while (0 < x) {}") should
    parseTo[Expression](
      WhileExp(
        LessExp(IntExp(0), IdnExp(IdnUse("x"))),
        Block(Vector()))
    )
  }

  //Testing the returnexp parser
  test("Parsing an expression that has a return value") {
    returnexp("return 4") should
    parseTo[Expression](
      Return(Some(IntExp(4)))
    )
  }

  test("Parsing an expression that has an empty return value") {
    returnexp("return") should
    parseTo[Expression](
      Return(None)
    )
  }

  test("Parsing an expression that does equations in the return") {
    returnexp("return x * 4") should
    parseTo[Expression](
      Return(
        Some(
          StarExp(
            IdnExp(IdnUse("x")),
            IntExp(4))))
    )
  }

  //Testing the letdecl parser
  test("Parsing a value x through letdecl") {
    letdecl("let x = 5;") should
    parseTo[Expression](
      LetDecl(IdnDef("x"), IntExp(5))
    )
  }

  test("Parsing a value x through letmutdecl") {
    letdecl("let mut x = 10;") should
    parseTo[Expression] (
      LetMutDecl(IdnDef("x"), IntExp(10))
    )
  }

  test("Parsing a value x through letdecl but trying to assign a value to it") {
    letdecl("let x := 5;") should
    failParseAt(1,7, "'=' expected but ':' found")
  }

  test("Parsing a value x through letmutdecl but trying to assign a value to it") {
    letdecl("let mut x := 10;") should
    failParseAt(1,11, "'=' expected but ':' found")
  }

  //Testing the fndecl parser
  test("Parsing a function double to a value x") {
    fndecl("fn double(x : int) -> int { x * 2 };") should
    parseTo[Expression](
      FnDecl(
        IdnDef("double"),
        Vector(ParamDecl(IdnDef("x"), IntType())),
        Some(IntType()),
        Block(Vector(StarExp(IdnExp(IdnUse("x")), IntExp(2)))))
    )
  }

  test("Parsing a function where everything is empty") {
    fndecl("fn double() -> int {};") should
    parseTo[Expression](
      FnDecl(
        IdnDef("double"),
        Vector(),
        Some(IntType()),
        Block(Vector()))
    )
  }

  test("Parsing a function which doesn't have a type") {
    fndecl("fn double(x : int) { x * 2 };") should
    parseTo[Expression](
      FnDecl(
        IdnDef("double"),
        Vector(ParamDecl(IdnDef("x"), IntType())),
        None,
        Block(Vector(StarExp(IdnExp(IdnUse("x")), IntExp(2)))))
    )
  }

  test("Parsing a function which has a type but does not have an arrow") {
    fndecl("fn double(x : int) int { x * 2 };") should
    failParseAt(1,20, "'{' expected but 'i' found")
  }

  test("Parsing a function that does not apply to a value") {
    fndecl("fn (x : int) -> int { x * 2 };") should
    failParseAt(1,4, "string matching regex '[a-zA-Z][a-zA-Z0-9_]*' expected but '(' found")
  }

  //Testing the paramdecl parser
  test("Parsing parameter for int") {
    paramdecl("x : int") should
    parseTo[Expression](
      ParamDecl(IdnDef("x"), IntType())
    )
  }

  test ("Parsing parameter for bool") {
    paramdecl("y : bool") should
    parseTo[Expression](
      ParamDecl(IdnDef("y"), BoolType())
    )
  }

  test("Parsing parameter for unit") {
    paramdecl("z : unit") should
    parseTo[Expression](
      ParamDecl(IdnDef("z"), UnitType())
    )
  }

  test("Parsing parameter for function") {
    paramdecl("a : fn (int, bool) -> unit") should
    parseTo[Expression](
      ParamDecl(
        IdnDef("a"),
        FnType(Vector(IntType(), BoolType()), UnitType()))
    )
  }

  test("Parsing parameter that does not have a type") {
    paramdecl("x : 5") should
    failParseAt(1,5,"'(' expected but '5' found")
  }
}
