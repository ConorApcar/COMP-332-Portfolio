/*
 * This file is part of COMP332 Assignment 3 2018.
 *
 * Lintilla, a simple functional programming language.
 *
 * © 2018, Dominic Verity, Macquarie University, All rights reserved.
 *
 * This Source Code Form is subject to the terms of the Mozilla Public
 * License, v. 2.0. If a copy of the MPL was not distributed with this
 * file, You can obtain one at http://mozilla.org/MPL/2.0/.
 *
 * Execution tests.
 */

package lintilla

import org.junit.runner.RunWith
import org.scalatest.junit.JUnitRunner

/**
  * Tests to check that the execution of SEC machine code translated from
  * Lintilla source code gives the right output.
  */
@RunWith(classOf[JUnitRunner])
class ExecTests extends SemanticTests {

  import SECTree._

  test("print a constant integer gives the right output") {
    execTestInline("""
       |print(30)""".stripMargin, "30\n")
  }

  test("print a constant integer gives the right translation") {
    targetTestInline("""
       |print(30)""".stripMargin,
                     List(IInt(30), IPrint()))
  }

  test("Print an addition equation that gives the right output") {
    execTestInline("""
    |print(2+2)""".stripMargin, "4\n")
  }

  test("print an addition equation that gives the right translation") {
    targetTestInline("""
    |print(2+2)""".stripMargin,
                   List(IInt(2), IInt(2), IAdd(), IPrint()))
  }

  test("Print true and makes sure it gives the right output") {
    execTestInline("""
    |print(true)""".stripMargin, "true\n")
  }

  test("Print true and makes sure it gives the right translation") {
    targetTestInline("""
    |print(true)""".stripMargin,
                    List(IBool(true), IPrint()))
  }

  test("Print false and makes sure it gives the right output") {
    execTestInline("""
    |print(false)""".stripMargin, "false\n")
  }

  test("Print false and makes sure it gives the right translation") {
    targetTestInline("""
    |print(false)""".stripMargin,
                     List(IBool(false), IPrint()))
  }

  test("Print a minus equation that gives the right output") {
    execTestInline("""
    |print(10-4)""".stripMargin, "6\n")
  }

  test("print a minus equation that gives the right translation") {
    targetTestInline("""
    |print(10-4)""".stripMargin,
                    List(IInt(10), IInt(4), ISub(), IPrint()))
  }

  test("Print a multiplication equation that gives the right output") {
    execTestInline("""
    |print(5*4)""".stripMargin, "20\n")
  }

  test("print a multiplication equation that gives the right translation") {
    targetTestInline("""
    |print(5*4)""".stripMargin,
                   List(IInt(5), IInt(4), IMul(), IPrint()))
  }

  test("Print a division equation that gives the right output") {
    execTestInline("""
    |print(24/8)""".stripMargin, "3\n")
  }

  test("print a divison equation that gives the right translation") {
    targetTestInline("""
    |print(24/8)""".stripMargin,
                   List(IInt(24), IInt(8), IDiv(), IPrint()))

  }
}
