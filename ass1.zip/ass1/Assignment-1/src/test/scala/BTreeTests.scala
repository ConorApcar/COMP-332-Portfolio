/*
 * This file is part of COMP332 Assignment 1.
 *
 * Copyright (C) 2018 Dominic Verity, Macquarie University.
 *
 * This Source Code Form is subject to the terms of the Mozilla Public
 * License, v. 2.0. If a copy of the MPL was not distributed with this
 * file, You can obtain one at http://mozilla.org/MPL/2.0/.
 *
 * Tests of the B-tree implementation. Uses the ScalaTest `FlatSpec` style
 * for writing tests. See
 *
 *      http://www.scalatest.org/user_guide
 *
 * For more info on writing ScalaTest tests.
 */

import org.scalatest.FlatSpec
import org.scalatest.Matchers

class BTreeSpec extends FlatSpec with Matchers {

  import BTree._
  val testPrint = BTree[Int](5,7,1,9,13,11,10,2).toString

  "An empty B-tree:" should "have size 0" in {
    assert (BTree[Int]().size == 0)
  }

  it should "have depth 0" in {
    assertResult(0) {
      BTree[Int]().depth
    }
  }

  it should "return `None` when `find` is invoked" in {
    assertResult(None) {
      BTree[String]().find("Hello")
    }
  }

  it should "return the empty B-tree when `delete` is invoked" in {
    assertResult(EmptyNode[Int]()) {
      BTree[Int]().delete(10)
    }
  }

  it should "return a singleton B-tree when `insert` is invoked" in {
    assertResult(TwoNode(EmptyNode[String](), "Hello", EmptyNode[String]())) {
      BTree[String]().insert("Hello")
    }
  }

  it should "return the empty list when `inOrder` is invoked" in {
    assertResult(Nil) {
      BTree[String]().inOrder
    }
  }

  it should "pretty print to the string \"EmptyNode()\"" in {
    assertResult("EmptyNode()") {
      BTree[(Int, Int)]().toString
    }
  }

  //FIND() TESTING
  "A B-tree using find():" should "return a string item if it exists in the list" in {
    assertResult(Some("too")) {
      BTree[String]("when", "too", "much", "sport").find("too")
    }
  }

  it should "return a number item if it exists in the list" in {
    assertResult(Some(3)) {
      BTree[Int](1,2,3,4).find(3)
    }
  }

  it should "find the word in t2" in {
    assertResult(Some("unit")) {
      EgBTrees.t2.find("unit")
    }
  }

  it should "find a number in t1" in {
    assertResult(Some(1)) {
      EgBTrees.t1.find(1)
    }
  }

  it should "return 'None' once it has gone through the list and not found the item" in {
    assertResult(None) {
      BTree[Int](1,2,3,4).find(5)
    }
  }

  //INORDER() TESTING
  "A B-tree using inOrder():" should "return a BTree[Int] of three nodes in ascending order" in {
    assertResult(List(1,2,3,4,5,6,7,8,9,10)) {
      BTree[Int](3,6,9,1,2,4,8,10,5,7).inOrder()
    }
  }

  it should "return a BTree[Int] of two nodes in ascending order" in {
    assertResult(List(1,2,3,4,5,6,7)) {
      BTree[Int](1,3,5,7,2,4,6).inOrder()
    }
  }

  it should "return a Btree[Int] in ascending order without duplicates" in {
    assertResult(List(1,2,3,4)) {
      BTree[Int](2,2,2,3,4,1,4,2,1,3,1,2,3,4).inOrder()
    }
  }

  it should "return a BTree[String] in alphabetical order" in {
    assertResult(List("Astro", "Tide", "Zorro", "dip", "dork", "got", "weep")) {
      BTree[String]("dip", "Astro", "got", "dork", "Zorro", "Tide", "weep").inOrder()
    }
  }


  it should "return t1 in ascending order" in {
    assertResult(List(-1,1,2,3,5,6,7,9,11,12,13,14,15,23)) {
      EgBTrees.t1.inOrder()
    }
  }

  it should "return t2 in alphabetical order" in {
    assertResult(List("COMP332", "a", "are", "barely", "enough!", "in", "many", "too", "trees", "unit", "which")) {
      EgBTrees.t2.inOrder()
    }
  }

  //PPRINT() TESTING
  "A B-tree using pprint():" should "return the start of the string" in {
    testPrint should startWith("TwoNode(")
  }

  it should "show the values that are included in the string" in {
    testPrint should include("Entry: 5,")
    testPrint should include("Entry: 9,")
    testPrint should include("Entry: 10,")
  }

  it should "return the end of the string" in {
    testPrint should endWith("EmptyNode())))")
  }

  it should "return the start of the string for t2" in {
    EgBTrees.t2.toString should startWith("TwoNode(")
  }

  it should "show the values that are included in the string of t2" in {
    EgBTrees.t2.toString should include("Entry: enough!,")
    EgBTrees.t2.toString should include("Entry: too,")
    EgBTrees.t2.toString should include("Entry: COMP332,")
  }

  it should "return the end of the string for t2" in {
    EgBTrees.t2.toString should endWith("EmptyNode())))")
  }
}
